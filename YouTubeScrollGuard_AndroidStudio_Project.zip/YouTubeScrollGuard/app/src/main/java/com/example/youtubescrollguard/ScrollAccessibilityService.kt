package com.example.youtubescrollguard

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ScrollAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }
    private var lastScrollAt = 0L
    private var youtubeWasForeground = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val packageName = event.packageName?.toString() ?: return
        val inYouTube = packageName == YOUTUBE_PACKAGE

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (inYouTube && !youtubeWasForeground) {
                prefs.edit().putInt("count", 0).apply()
                lastScrollAt = 0L
            }
            youtubeWasForeground = inYouTube
            return
        }

        if (!inYouTube || event.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) return

        val now = System.currentTimeMillis()
        // Some YouTube views emit several accessibility scroll events for one gesture.
        // Debounce nearby events to reduce accidental double counting.
        if (now - lastScrollAt < DEBOUNCE_MS) return
        lastScrollAt = now

        val next = prefs.getInt("count", 0) + 1
        prefs.edit().putInt("count", next).apply()

        // "30개를 넘기면" is interpreted literally as the 31st detected scroll.
        if (next > LIMIT) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            youtubeWasForeground = false
        }
    }

    override fun onInterrupt() = Unit

    companion object {
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        private const val LIMIT = 30
        private const val DEBOUNCE_MS = 600L
    }
}
