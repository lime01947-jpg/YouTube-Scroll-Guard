package com.example.youtubescrollguard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var countView: TextView
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "YouTube Scroll Guard"
            textSize = 25f
            gravity = Gravity.CENTER
        }
        countView = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 12)
        }
        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }

        val permissionButton = Button(this).apply {
            text = "접근성 권한 설정"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val resetButton = Button(this).apply {
            text = "카운터 초기화"
            setOnClickListener {
                prefs.edit().putInt("count", 0).apply()
                refresh()
            }
        }

        layout.addView(title)
        layout.addView(countView)
        layout.addView(status)
        layout.addView(permissionButton)
        layout.addView(resetButton)
        setContentView(layout)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val count = prefs.getInt("count", 0)
        countView.text = "현재 카운트: $count / 30"
        status.text = "유튜브에서 31번째 스크롤이 감지되면 홈 화면으로 이동합니다.\n접근성 권한을 켜야 작동합니다."
    }
}
